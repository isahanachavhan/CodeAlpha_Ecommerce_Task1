# CodeAlpha E-Commerce Store

A complete beginner-friendly Django full-stack e-commerce project created for the CodeAlpha internship Task 1.

## Features
- Product listing
- Product details
- Shopping cart
- Quantity update/remove
- User registration and login
- Checkout/order processing
- Order history
- SQLite database
- Admin panel for products and orders
- Responsive HTML/CSS/JavaScript UI

## Run locally

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python manage.py migrate
python manage.py seed_products
python manage.py runserver
```

Open http://127.0.0.1:8000/

Admin:
```bash
python manage.py createsuperuser
```
Then open http://127.0.0.1:8000/admin/

## Demo flow
1. Register a user.
2. Browse products.
3. Open a product and add it to cart.
4. Update/remove items in cart.
5. Checkout and place an order.
6. View the order under My Orders.

## GitHub repository name requested by CodeAlpha
`CodeAlpha_Ecommerce`
