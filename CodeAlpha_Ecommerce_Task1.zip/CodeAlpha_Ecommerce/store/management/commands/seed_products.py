from django.core.management.base import BaseCommand
from store.models import Product

PRODUCTS = [
    ("Nova Laptop", "Powerful everyday laptop for students and developers.", 54999, "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800", 12),
    ("Pro Headphones", "Wireless over-ear headphones with rich sound.", 2499, "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800", 25),
    ("Smart Watch", "Fitness tracking, notifications and modern design.", 3299, "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800", 18),
    ("Mechanical Keyboard", "Comfortable RGB mechanical keyboard for coding.", 1999, "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800", 20),
    ("Gaming Mouse", "High precision mouse for work and gaming.", 1299, "https://images.unsplash.com/photo-1527814050087-3793815479db?w=800", 30),
    ("USB-C Hub", "Multi-port hub for laptops and tablets.", 999, "https://images.unsplash.com/photo-1625842268584-8f3296236761?w=800", 35),
]

class Command(BaseCommand):
    help = "Create demo products for the CodeAlpha project"

    def handle(self, *args, **options):
        Product.objects.all().delete()
        for name, desc, price, image, stock in PRODUCTS:
            Product.objects.create(name=name, description=desc, price=price, image_url=image, stock=stock)
        self.stdout.write(self.style.SUCCESS("Demo products created successfully."))
