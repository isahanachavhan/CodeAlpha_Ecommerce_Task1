from decimal import Decimal
from functools import wraps

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from .models import Order, OrderItem, Product

def cart_count(request):
    return sum(request.session.get("cart", {}).values())

def base_context(request):
    return {"cart_count": cart_count(request)}

def home(request):
    products = Product.objects.all()
    return render(request, "home.html", {"products": products, **base_context(request)})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, "product_detail.html", {"product": product, **base_context(request)})

def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart = request.session.get("cart", {})
    key = str(pk)
    current = int(cart.get(key, 0))
    if current < product.stock:
        cart[key] = current + 1
        request.session["cart"] = cart
        messages.success(request, f"{product.name} added to your cart.")
    else:
        messages.warning(request, "Sorry, this product is out of stock.")
    return redirect(request.META.get("HTTP_REFERER", "home"))

def cart(request):
    raw = request.session.get("cart", {})
    items, total = [], Decimal("0.00")
    for pk, quantity in raw.items():
        product = Product.objects.filter(pk=pk).first()
        if product:
            subtotal = product.price * quantity
            items.append({"product": product, "quantity": quantity, "subtotal": subtotal})
            total += subtotal
    return render(request, "cart.html", {"items": items, "total": total, **base_context(request)})

def update_cart(request, pk):
    if request.method == "POST":
        try:
            quantity = max(1, int(request.POST.get("quantity", 1)))
        except ValueError:
            quantity = 1
        product = get_object_or_404(Product, pk=pk)
        cart = request.session.get("cart", {})
        cart[str(pk)] = min(quantity, product.stock)
        request.session["cart"] = cart
        messages.success(request, "Cart updated.")
    return redirect("cart")

def remove_from_cart(request, pk):
    cart = request.session.get("cart", {})
    cart.pop(str(pk), None)
    request.session["cart"] = cart
    messages.info(request, "Item removed from cart.")
    return redirect("cart")

@login_required
def checkout(request):
    raw = request.session.get("cart", {})
    products = Product.objects.filter(pk__in=raw.keys())
    lines, total = [], Decimal("0.00")
    for product in products:
        quantity = int(raw.get(str(product.pk), 0))
        if quantity <= 0:
            continue
        subtotal = product.price * quantity
        lines.append((product, quantity, subtotal))
        total += subtotal

    if not lines:
        messages.warning(request, "Your cart is empty.")
        return redirect("home")

    if request.method == "POST":
        with transaction.atomic():
            for product, quantity, _ in lines:
                if product.stock < quantity:
                    messages.error(request, f"Not enough stock for {product.name}.")
                    return redirect("cart")
            order = Order.objects.create(user=request.user, total_price=total)
            for product, quantity, _ in lines:
                OrderItem.objects.create(order=order, product=product, quantity=quantity, price=product.price)
                product.stock -= quantity
                product.save(update_fields=["stock"])
        request.session["cart"] = {}
        messages.success(request, f"Order #{order.id} placed successfully!")
        return redirect("orders")

    return render(request, "checkout.html", {"lines": lines, "total": total, **base_context(request)})

@login_required
def orders(request):
    user_orders = Order.objects.filter(user=request.user).prefetch_related("items__product")
    return render(request, "orders.html", {"orders": user_orders, **base_context(request)})

def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "")
        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            login(request, user)
            messages.success(request, "Account created successfully.")
            return redirect("home")
    return render(request, "register.html", base_context(request))

def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect("home")
        messages.error(request, "Invalid username or password.")
    return render(request, "login.html", base_context(request))

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("home")
